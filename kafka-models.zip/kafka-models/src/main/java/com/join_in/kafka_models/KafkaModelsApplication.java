package com.join_in.kafka_models;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaModelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaModelsApplication.class, args);
	}

}
