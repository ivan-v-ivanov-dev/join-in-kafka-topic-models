package com.join_in.kafka_models;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaModelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
